﻿namespace $safeprojectname$
{
    partial class $safeprojectname$
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof($safeprojectname$));
            this.tabMain.SuspendLayout();
            this.tpFlow.SuspendLayout();
            this.tpSuperSetting.SuspendLayout();
            this.TabFlow.SuspendLayout();
            this.SuspendLayout();
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.Images.SetKeyName(0, "position.png");
            this.imgList.Images.SetKeyName(1, "motor.png");
            this.imgList.Images.SetKeyName(2, "setting.png");
            this.imgList.Images.SetKeyName(3, "checklist.png");
            this.imgList.Images.SetKeyName(4, "edit.png");
            this.imgList.Images.SetKeyName(5, "save.png");
            this.imgList.Images.SetKeyName(6, "cancel.png");
            this.imgList.Images.SetKeyName(7, "addrow.png");
            this.imgList.Images.SetKeyName(8, "delrow1.png");
            // 
            // tabMain
            // 
            this.tabMain.Size = new System.Drawing.Size(909, 539);
            // 
            // tpControl
            // 
            this.tpControl.Size = new System.Drawing.Size(901, 471);
            // 
            // tpPosition
            // 
            this.tpPosition.Size = new System.Drawing.Size(901, 471);
            // 
            // tpSetting
            // 
            this.tpSetting.Size = new System.Drawing.Size(901, 471);
            // 
            // tpFlow
            // 
            this.tpFlow.Size = new System.Drawing.Size(901, 471);
            // 
            // tpSuperSetting
            // 
            this.tpSuperSetting.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tpSuperSetting.Size = new System.Drawing.Size(901, 471);
            // 
            // TabFlow
            // 
            this.TabFlow.Size = new System.Drawing.Size(897, 467);
            // 
            // tpHome
            // 
            this.tpHome.Size = new System.Drawing.Size(889, 425);
            // 
            // tpAuto
            // 
            this.tpAuto.Location = new System.Drawing.Point(4, 38);
            this.tpAuto.Size = new System.Drawing.Size(889, 425);
            // 
            // $safeprojectname$
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 539);
            this.Name = "$safeprojectname$";
            this.Text = "$safeprojectname$";
            this.tabMain.ResumeLayout(false);
            this.tpFlow.ResumeLayout(false);
            this.tpSuperSetting.ResumeLayout(false);
            this.tpSuperSetting.PerformLayout();
            this.TabFlow.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion


    }
}